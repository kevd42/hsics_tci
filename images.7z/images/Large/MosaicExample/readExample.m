cubename='./VIS_leaves_FD1_FN0_original.hdr';

[ cubename,lines,samples,bands,defaultBands, interleave, wavelengths ] = parsecube( cubename );
disp([ num2str(lines) 'x' num2str(samples) 'x' num2str(bands) ' cube'])


% Setup default false color image
figure
XR = multibandread(cubename,[lines,samples,bands],'uint16',0,interleave,'ieee-le',{'Band','Range',[defaultBands(1) defaultBands(1) ]});
XG = multibandread(cubename,[lines,samples,bands],'uint16',0,interleave,'ieee-le',{'Band','Range',[defaultBands(2) defaultBands(2) ]});
XB = multibandread(cubename,[lines,samples,bands],'uint16',0,interleave,'ieee-le',{'Band','Range',[defaultBands(3) defaultBands(3) ]});
im(:,:,1)=XR;
im(:,:,2)=XB;
im(:,:,3)=XG;
imshow(im/max(im(:)))

%read full cube
cube = multibandread(cubename,[lines,samples,bands],'uint16',0,interleave,'ieee-le');
figure
n=1;
plot(wavelengths,squeeze(cube(90+(-n:n),300,:)),'k-+')
hold on
plot(wavelengths,squeeze(cube(27+(-n:n),294,:)),'g-+')
plot(wavelengths,squeeze(cube(130+(-n:n),350,:)),'m-+')


