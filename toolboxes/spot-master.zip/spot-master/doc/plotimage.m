function plotimage(Y)
%plotimage  adds a few options to Matlab's imagesc.
   imagesc(Y)
   colormap gray
   axis image
   axis off   
end % function