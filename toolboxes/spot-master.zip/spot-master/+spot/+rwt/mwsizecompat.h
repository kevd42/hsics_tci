/* Older versions of Matlab don't define mwSize or mwIndex;
   use int instead. */
#ifndef mwSize
#define mwSize int
#endif
#ifndef mwIndex
#define mwIndex int
#endif
